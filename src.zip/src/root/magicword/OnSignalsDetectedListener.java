package root.magicword;

public interface OnSignalsDetectedListener{
	public abstract void onWhistleDetected();
}